<?php

// Re�oit une requ�te JSON par POST et retourne un accus� de r�ception
// Vu la fa�on dont la variable super globale $_POST traite les fichiers strictement JSON
// je fais des tests de contenu 
// lire https://stackoverflow.com/questions/8893574/php-php-input-vs-post
// https://www.php.net/manual/en/reserved.variables.server.php

/*
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "title":"Zone de navigation",
        "description":"Zone interdite aux pecheurs",
       },
      "geometry": {
        "coordinates": [            // Sens horaire ? A v�rifier
          [                         // Contour 
            [                       // Premier points 
              -1.4746555619712751,
              47.243830107759834
            ],
            [
              -1.4733794850961033,
              47.24306984068747
            ],
            [
              -1.4732841764495106,
              47.24323699253995
            ],
 ...
            [                       // Dernier point = Premier point
              -1.4746555619712751,
              47.243830107759834
            ]
          ],
          []                        // Trous
        ],
        "type": "Polygon"
      }
    }
  ]
}

*/

$debug = true;
$zonenav = new stdclass();

$reponse_ok = '"ok":1';
$reponse_not_ok = '"ok":0';

$data = null;

// Get the JSON contents
if (isset($_SERVER['REQUEST_METHOD']) && (strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST')) {
  throw new Exception('Only POST requests are allowed');
}
if (isset($_SERVER['CONTENT_TYPE']) && (stripos($_SERVER['CONTENT_TYPE'], 'application/json') === false)) {
  throw new Exception('Content-Type must be application/json');
}

if (isset($_POST) && !empty($_POST)) {
    //echo "POST : "; 
    //print_r($_POST); // pas de debug car �a fait boguer le programme
    $data = $_POST;  
}
else {
    // Read the input stream
    //echo "php://input "; // Cet echo fait boguer le programme
    $data = file_get_contents("php://input");
    if ($debug){
        file_put_contents("debug_zn.txt", $data);
    } 
    
}

if (isset($data) && (!empty($data)))
{   
    // $zonenav = json_decode($data);
    
    // Do what you have to do... but do not use print nor echo !:>))
    // Zone de navigation
     
    // return value
    //$reponse = '{'.$reponse_ok.','.substr($data,1).'}'; // Chasser la premi�re accolade
 
    //echo $reponse; 
     echo '{'.$reponse_ok.'}';
}
else {
    echo '{'.$reponse_not_ok.'}';
}
?>
