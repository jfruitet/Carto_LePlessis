<?php

// Re�oit une requ�te JSON par POST et retourne un accus� de r�ception
// Vu la fa�on dont la variable super globale $_POST traite les fichiers strictement JSON
// je fais des tests de contenu 
// lire https://stackoverflow.com/questions/8893574/php-php-input-vs-post
// https://www.php.net/manual/en/reserved.variables.server.php


$debug = true;

$bouees = new stdClass();

$reponse_ok = '"ok":1';
$reponse_not_ok = '"ok":0';

$data = null;

// Get the JSON contents
if (isset($_SERVER['REQUEST_METHOD']) && (strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST')) {
  throw new Exception('Only POST requests are allowed');
}
if (isset($_SERVER['CONTENT_TYPE']) && (stripos($_SERVER['CONTENT_TYPE'], 'application/json') === false)) {
  throw new Exception('Content-Type must be application/json');
}

if (isset($_POST) && !empty($_POST)) {
    //echo "POST : "; 
    //print_r($_POST); // pas de debug car �a fait boguer le programme
    $data = $_POST;  
}
else {
    // Read the input stream
    //echo "php://input "; // Cet echo fait boguer le programme
    $data = file_get_contents("php://input");
    
    if (debug){
        file_put_contents("debug_bf.txt", $data);
    }
}

if (isset($data) && (!empty($data)))
{
    $bouees = json_decode($data);
    if ($debug){
        file_put_contents("debug_bf.txt", $bouees, FILE_APPEND);
    } 
    // Do what you have to do... but do not use print nor echo !:>))
    // Zone de navigation
    
     
    // return value
    $reponse = '{'.$reponse_ok.','.substr($data,1); // Chasser la premi�re accolade
 
    if ($debug){
        file_put_contents("debug_bf.txt",$reponse, FILE_APPEND);
    }    

    echo $reponse; 
}
else {
    echo '{'.$reponse_not_ok.'}';
}
?>
