<?php

// Re�oit une requ�te JSON par POST et retourne un accus� de r�ception
// Vu la fa�on dont la variable super globale $_POST traite les fichiers strictement JSON
// je fais des tests de contenu 
// lire https://stackoverflow.com/questions/8893574/php-php-input-vs-post
// https://www.php.net/manual/en/reserved.variables.server.php
// Si le script ne renvoie aucun contenu c'est que le code JSON est mal form� ;>()

$debug = false;

$mydata = new stdClass();

$reponse_ok = '"ok":1';
$reponse_not_ok = '"ok":0';

$data = null;

// Get the JSON contents
if (isset($_SERVER['REQUEST_METHOD']) && (strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST')) {
  throw new Exception('Only POST requests are allowed');
}
if (isset($_SERVER['CONTENT_TYPE']) && (stripos($_SERVER['CONTENT_TYPE'], 'application/json') === false)) {
  throw new Exception('Content-Type must be application/json');
}

if (isset($_POST) && !empty($_POST)) {
    $data = $_POST;  
}
else {
    // Read the input stream
    $data = file_get_contents("php://input");
    
    if ($debug){
        file_put_contents("debug_test.txt", $data);
    }
}

if (isset($data) && (!empty($data)))
{
    $mydata = json_decode($data,true);
    if ($debug){
        file_put_contents("debug_test.txt", "\n", FILE_APPEND);
        if (!empty($mydata)){
            file_put_contents("debug_test.txt", $mydata, FILE_APPEND);
            file_put_contents("debug_test.txt", "\n", FILE_APPEND);
            $strmydata="";
            foreach($mydata as $item){
                $strmydata.="\t".$item; 
            } 
            file_put_contents("debug_test.txt", $strmydata, FILE_APPEND);
        }
        else{
            file_put_contents("debug_test.txt", "\$mydata est vide...\n", FILE_APPEND);               
        }
    } 
    // Do what you have to do... but do not use print nor echo !:>))
    // Ici placez votre code de traitement, sans utiliser ni echo() ni print()  !:>))
    
     
    // return value
    $reponse = '{'.$reponse_ok.','.substr($data,1); // Chasser la premi�re accolade
 
    if ($debug){
        file_put_contents("debug_test.txt",$reponse, FILE_APPEND);
    }    

    echo $reponse; 
}
else {
    echo '{'.$reponse_not_ok.'}';
}
?>
