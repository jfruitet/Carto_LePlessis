<?php
echo '<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Carto Le Plessis</title>
  <link rel="stylesheet" href="style.css">
  <!-- script src="script.js"></script -->
</head>';
echo '<body>';
echo '<h1>Carto Le Plessis</h1>
<p>Gestionnaire de parcours de régates virtuelles sur le plan d\'eau du Plessis</p>
<p><a mailto="jean.fruitet@free.fr?subject=Carto Le Plessis">jean.fruitet@free.fr</a></p>
<p>Ceci est une page minimale...';
echo '</body></html>';
?>
