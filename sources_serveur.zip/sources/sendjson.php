<?php
// Envoie une requête JSON
// Warning: this won't work if the allow_url_fopen setting is set to Off in the php.ini file.
// https://stackoverflow.com/questions/6213509/send-json-post-request-with-php
// Si le script ne renvoie aucun contenu c'est que le code JSON est mal formé ;>()

// Adresse à remplacer par celle de votre serveur
$url = 'http://localhost/cartoleplessis/getjson.php';

// Format JSON
$myjson = '{"id":1, "firstname":"Jean", "lastname":"Fruitet", "mail":"jean.fruitet@free.fr"}'; 

// Format objet PHP : doit être encodé avec json_encode()
$myobjectjson = array(    
  'id'      => 1,
  'firstname'    => 'Jean',
  'lastname '       => 'Fruitet',
  'mail' => 'jean.fruitet@free.fr'
);

$options = array(
  'http' => array(
    'method'  => 'POST',
    'content' => $myjson, // json_encode( $myobjectjson ), quand les données sont fournies dans un objet PHP 
    'header'=>  "Content-Type: application/json\r\n" .
                "Accept: application/json\r\n"
    )
);

$context  = stream_context_create( $options );
$result = file_get_contents( $url, false, $context );
// print($result);
if (!empty($result)){
    $response = json_decode( $result );
    echo '<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Test client / servur</title>
  <link rel="stylesheet" href="style.css">
  <!-- script src="script.js"></script -->
</head><body>'."\n<h3>Test Client / Serveur</h3>\n<p>Ce script envoie des données formatées JSON au un serveur PHP <i>";
echo $url."</i>\n<br />
Celui-ci retourne les données reçues augmentées d'un accusé de réception de type {\"ok\":1} 
ou {\"ok\":0} en fonction du succès ou de l'échec de la requête...</p>\n<p>\n";
    echo("Données envoyées : <i>".$myjson."</i><br />\n");
    echo("Données reçues non décodées : <i>".$result."</i><br />\n");
    echo("Données reçues décodées : <i>");
    print_r($response);
    echo("</i><br />");
    $strmydata="";
    foreach($response as $item){
        $strmydata.=$item.", "; 
    } 
    echo("\nDonnées reçues transformées en chaîne de valeurs avec séparateur \",\": <i>". $strmydata. "</i><br />\n");
    $strmydata="";
    foreach($response as $key => $value){
        $strmydata.=" &lt;".$key.":".$value."&gt;"; 
    } 
    echo("\nDonnées reçues transformées en chaîne de &lt;clé:valeur&gt; : <i>". $strmydata. "</i><br />\n");
    
    if (isset($response->ok) && ($response->ok==1)){
        echo "\n<br />Succès\n";
    } 
    else{
        echo "\n<br />Echec\n";   
    }
    echo "</p>\n<small>Si aucune donnée n'est retournée c'est que le code JSON est mal formé !;&gt;()</small><br />\n";
    echo '<a href="index.php">Retour</a>'."\n";
    echo '</body></html>'."\n";
}    
?>
