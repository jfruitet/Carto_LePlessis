<?php
// Nothing to do here

echo '<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Carto Le Plessis</title>
  <link rel="stylesheet" href="style.css">
  <!-- script src="script.js"></script -->
</head>';
echo '<body>';
echo '<h1>Carto Le Plessis</h1>
<p>Gestionnaire de parcours de régates virtuelles sur le plan d\'eau du Plessis</p>
<p><a mailto="jean.fruitet@free.fr?subject=Carto Le Plessis">jean.fruitet@free.fr</a></p>
<h2>GitHub</h2>
<ul><li>
Sources : <a href="https://github.com/jfruitet/Carto_LePlessis" target="_blank">https://github.com/jfruitet/Carto_LePlessis</a>
</li>
<li>Information : <a href="https://github.com/jfruitet/Carto_LePlessis#readme.md" target="_blank">https://github.com/jfruitet/Carto_LePlessis#readme.md</a>
</li>
</ul>
<h2>Serveur</h2>
<p>Il faut un serveur disponible sur le Web pour traiter les données de placement des bouées et la zone de navigation.
<ul><li>Pour la zone de navigation le code JSON attendu par ce serveur a la structure :
<a href="exemple_json_zone_navigation.html">JSON Zone de Navigation</a>
</li>
<li>Pour la liste des bouées fixes le code JSON a la structure :
<a href="exemple_json_bouees_fixes.html">JSON Bouées fixes</a>
</li>
<li>En cas de succès de l\'optimisation du placement le code JSON retourné contient :
<pre>{"ok":1}</pre> et la liste des positions optimales pour les bouées du parcours.</p>
<p>En cas d\'échec le code JSON retourné contient <pre>{"ok":0}</pre></p>
<h3>Serveurs de test de requêtes JSON en PHP</h3>
<p>J\'ai eu pas mal de difficultés à faire fonctionner un serveur en PHP. <br />
Le problème provient du type mime <i>application/json</i> non supporté en mode natif par la variable super globale <i>$_POST</i>.
<br />Finalement côté serveur ce code <a href="sources_getjson.php.html">getjson.php</a> fonctionne en testant le contenu de <i>$_POST</i>.</p>
<p>Côté client :  <a href="sources_sendjson.php.html">sendjson.php</a></p>
<h3>Autres tests</h3>
<p><ul><li>Lire une page Web : <a href="getrequest.php">Go</a></li>
<li>Envoyer une requête en JSON : <a href="sendjson.php">Go</a></li>
</ul></p>';
echo '</body></html>';
?>
